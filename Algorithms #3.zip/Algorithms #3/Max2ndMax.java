
public class Max2ndMax {
	int max;
	int max2nd;
}
