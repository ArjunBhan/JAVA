
public class MaxMin {
	double max;
	double min;
	double diff;
}
